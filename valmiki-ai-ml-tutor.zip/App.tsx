
import React, { useState, useRef, useEffect } from 'react';
import { 
  BookOpen, 
  Code as CodeIcon,
  Headphones, 
  Image as ImageIcon, 
  GraduationCap, 
  Download,
  Loader2,
  AlertCircle,
  Copy,
  Check,
  Mic, 
  MicOff,
  Paperclip,
  Terminal,
  BrainCircuit,
  Zap,
  ArrowRight,
  Sparkles,
  Search,
  User,
  Bell,
  TrendingUp,
  Award,
  ChevronRight,
  Home,
  Layout,
  Star,
  Mail,
  Lock,
  LogIn,
  Github,
  Chrome,
  UserCircle,
  Settings,
  LogOut,
  Shield,
  CreditCard,
  Target,
  Clock,
  Briefcase,
  RefreshCcw,
  History
} from 'lucide-react';
import { LearningMode, Depth, GenerationState } from './types';
import { GeminiService } from './services/geminiService';

const FEATURES = [
  {
    title: "Theory",
    description: "Foundations",
    icon: <BookOpen className="w-5 h-5" />,
    color: "bg-blue-100/50 text-blue-600",
    mode: LearningMode.TEXT
  },
  {
    title: "Code",
    description: "Implementations",
    icon: <CodeIcon className="w-5 h-5" />,
    color: "bg-indigo-100/50 text-indigo-600",
    mode: LearningMode.CODE
  },
  {
    title: "Vocal",
    description: "Audio Lectures",
    icon: <Headphones className="w-5 h-5" />,
    color: "bg-purple-100/50 text-purple-600",
    mode: LearningMode.AUDIO
  },
  {
    title: "Visual",
    description: "Diagrams",
    icon: <ImageIcon className="w-5 h-5" />,
    color: "bg-pink-100/50 text-pink-600",
    mode: LearningMode.VISUAL
  }
];

const QUICK_STATS = [
  { label: "Mastery", value: "84%", icon: <Zap className="w-4 h-4 text-amber-500" /> },
  { label: "Streak", value: "12 Days", icon: <TrendingUp className="w-4 h-4 text-emerald-500" /> },
  { label: "Tier", value: "Elite", icon: <Award className="w-4 h-4 text-blue-500" /> }
];

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  
  const [topic, setTopic] = useState('');
  const [mode, setMode] = useState<LearningMode>(LearningMode.TEXT);
  const [depth, setDepth] = useState<Depth>(Depth.DETAILED);
  const [copied, setCopied] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [selectedFile, setSelectedFile] = useState<{ name: string, data: string, mimeType: string } | null>(null);
  const [activeTab, setActiveTab] = useState<'home' | 'lab' | 'saved' | 'settings'>('home');
  
  const [state, setState] = useState<GenerationState>({
    loading: false,
    content: null,
    audioUrl: null,
    imageUrl: null,
    error: null,
  });

  const gemini = useRef(new GeminiService()).current;
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.onresult = (event: any) => {
        setTopic(event.results[0][0].transcript);
        setIsListening(false);
      };
      recognitionRef.current.onend = () => setIsListening(false);
    }
  }, []);

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      try {
        recognitionRef.current?.start();
        setIsListening(true);
      } catch (err) {
        console.error('Speech recognition failed to start:', err);
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        setSelectedFile({
          name: file.name,
          data: base64String,
          mimeType: file.type
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  const handleLearn = async (targetTopic?: string, targetMode?: LearningMode) => {
    const finalTopic = targetTopic || topic;
    const finalMode = targetMode || mode;
    if (!finalTopic.trim() && !selectedFile) return;
    
    setState(prev => ({ ...prev, loading: true, error: null, content: null, audioUrl: null, imageUrl: null }));

    try {
      const content = await gemini.generateEducationalContent(
        finalTopic || (selectedFile ? `Analyzing: ${selectedFile.name}` : ''), 
        finalMode, 
        depth,
        selectedFile ? { data: selectedFile.data, mimeType: selectedFile.mimeType } : undefined
      );
      
      let audioUrl = null;
      let imageUrl = null;
      if (finalMode === LearningMode.AUDIO) audioUrl = await gemini.generateAudio(content);
      else if (finalMode === LearningMode.VISUAL) imageUrl = await gemini.generateVisual(finalTopic || selectedFile?.name || 'ML Concept');

      setState({
        loading: false,
        content,
        audioUrl,
        imageUrl,
        error: content.includes("I apologize") ? content : (content === "" ? "Generation failed" : null)
      });
    } catch (error: any) {
      setState(prev => ({ ...prev, loading: false, error: error.message || "An error occurred." }));
    }
  };

  const clearResearch = () => {
    setState({ loading: false, content: null, audioUrl: null, imageUrl: null, error: null });
    setTopic('');
    setSelectedFile(null);
  };

  const handleLogin = () => {
    if (!userName.trim() || !email.trim() || !password.trim()) {
      setLoginError("Verification failed: Please fill in all research credentials.");
      return;
    }
    setLoginError(null);
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserName('');
    setEmail('');
    setPassword('');
    setLoginError(null);
    setActiveTab('home');
    clearResearch();
  };

  const renderLogin = () => (
    <div className="min-h-screen flex items-center justify-center px-6 py-12 animate-in fade-in duration-1000">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center space-y-4">
          <div className="inline-flex p-4 rounded-3xl bg-white shadow-2xl shadow-blue-500/10 border border-white/50 animate-float">
            <GraduationCap className="w-12 h-12 text-blue-600" />
          </div>
          <div className="space-y-1">
            <h1 className="text-4xl font-black text-slate-900 tracking-tighter">VALMIKI</h1>
            <p className="text-slate-500 font-bold text-sm tracking-widest uppercase">Expert ML Research Environment</p>
          </div>
        </div>

        <div className="glass p-10 rounded-[3rem] space-y-6 border-white shadow-2xl relative overflow-hidden group">
          <div className="absolute -top-24 -left-24 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl group-hover:bg-purple-500/20 transition-all duration-1000"></div>
          
          <div className="space-y-4 relative z-10">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Researcher Name</label>
              <div className="relative group/input">
                <UserCircle className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within/input:text-blue-600 transition-colors" />
                <input 
                  type="text" 
                  value={userName}
                  onChange={(e) => {
                    setUserName(e.target.value);
                    if (loginError) setLoginError(null);
                  }}
                  placeholder="e.g., Ada Lovelace"
                  className="w-full bg-white/40 border border-white/60 pl-12 pr-4 py-4 rounded-2xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white/80 transition-all font-bold text-slate-800 placeholder:text-slate-300"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Access Portal</label>
              <div className="relative group/input">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within/input:text-blue-600 transition-colors" />
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (loginError) setLoginError(null);
                  }}
                  placeholder="researcher@valmiki.ai"
                  className="w-full bg-white/40 border border-white/60 pl-12 pr-4 py-4 rounded-2xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white/80 transition-all font-bold text-slate-800 placeholder:text-slate-300"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Security Key</label>
              <div className="relative group/input">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within/input:text-blue-600 transition-colors" />
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (loginError) setLoginError(null);
                  }}
                  placeholder="••••••••"
                  className="w-full bg-white/40 border border-white/60 pl-12 pr-4 py-4 rounded-2xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white/80 transition-all font-bold text-slate-800 placeholder:text-slate-300"
                />
              </div>
            </div>
          </div>

          <div className="pt-2 relative z-10 space-y-3">
            <button 
              onClick={handleLogin}
              className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-slate-900/20 hover:bg-blue-600 hover:scale-[1.02] hover:shadow-blue-600/30 active:scale-95 transition-all flex items-center justify-center space-x-3"
            >
              <span>Initialize Environment</span>
              <LogIn className="w-5 h-5" />
            </button>
            {loginError && (
              <p className="text-[10px] font-bold text-red-500 text-center animate-in slide-in-from-top-2">
                {loginError}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  const renderHomeLeft = () => (
    <div className="h-full space-y-8 animate-in fade-in slide-in-from-left-10 duration-700 max-w-sm mx-auto md:max-w-none">
      {/* Profile Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-white p-0.5 shadow-xl border border-white/50 overflow-hidden hover:scale-110 hover:shadow-2xl transition-all cursor-pointer" onClick={() => setActiveTab('settings')}>
            <img 
              src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${userName || 'Valmiki'}&backgroundColor=b6e3f4`} 
              alt="Avatar" 
              className="w-full h-full object-cover rounded-[14px]" 
            />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">Hi, {userName || 'Researcher'}</h2>
            <div className="flex items-center text-slate-500 font-semibold text-xs space-x-1">
              <Sparkles className="w-3 h-3 text-amber-500" />
              <span>Deep Learning Pro</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {QUICK_STATS.map((stat, i) => (
          <div key={i} className="glass p-3 lg:p-4 rounded-[1.8rem] text-center space-y-1 hover:bg-white/80 transition-all group cursor-default">
            <div className="mx-auto w-8 h-8 rounded-xl bg-white/50 flex items-center justify-center mb-1 group-hover:scale-125 group-hover:bg-white group-hover:shadow-lg transition-all">{stat.icon}</div>
            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{stat.label}</p>
            <p className="text-sm font-black text-slate-900">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* STABLE RESEARCH INPUT AREA */}
      <div className="space-y-4">
        <div className="bg-white/60 backdrop-blur-xl rounded-[2.2rem] p-2 lg:p-3 border border-white/60 flex items-center shadow-xl hover:shadow-2xl focus-within:bg-white/90 focus-within:ring-4 focus-within:ring-blue-500/10 transition-all">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <input 
              type="text" 
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleLearn()}
              placeholder="Query ML concept..."
              className="w-full pl-10 pr-4 py-4 rounded-2xl bg-transparent outline-none text-sm font-bold text-slate-800 placeholder:text-slate-400"
            />
          </div>
          <button 
            onClick={() => handleLearn()}
            disabled={state.loading}
            className="p-4 bg-blue-600 text-white rounded-2xl shadow-lg shadow-blue-500/20 hover:bg-blue-700 hover:scale-110 active:scale-90 transition-all disabled:opacity-50"
          >
            {state.loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ArrowRight className="w-5 h-5" />}
          </button>
        </div>
        <div className="flex flex-wrap gap-2 justify-between items-center px-2">
            <div className="flex space-x-2">
                <button onClick={toggleListening} className={`flex items-center space-x-2 px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all hover:scale-105 active:scale-95 shadow-sm hover:shadow-md ${isListening ? 'bg-red-100 text-red-600 animate-pulse ring-2 ring-red-500/20' : 'bg-blue-50 text-blue-600'}`}>
                    {isListening ? <MicOff className="w-3 h-3" /> : <Mic className="w-3 h-3" />}
                    <span className="hidden lg:inline">{isListening ? 'Listening' : 'Voice'}</span>
                </button>
                <button onClick={() => fileInputRef.current?.click()} className={`flex items-center space-x-2 px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all hover:scale-105 active:scale-95 shadow-sm hover:shadow-md ${selectedFile ? 'bg-blue-600 text-white shadow-blue-500/20' : 'bg-blue-50 text-blue-600'}`}>
                    <Paperclip className="w-3 h-3" />
                    <span className="hidden lg:inline">{selectedFile ? 'Attached' : 'Paper'}</span>
                </button>
            </div>
            {(state.content || state.error) && (
                <button onClick={clearResearch} className="flex items-center space-x-2 px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all hover:scale-105 active:scale-95 text-slate-400 hover:text-slate-600">
                    <RefreshCcw className="w-3 h-3" />
                    <span className="hidden lg:inline">Reset</span>
                </button>
            )}
        </div>
        <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept=".pdf,image/*" />
      </div>

      <div className="space-y-4">
        <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.3em] px-2">Modalities</h3>
        <div className="grid grid-cols-2 gap-3 lg:gap-4">
          {FEATURES.map((f, i) => (
            <div key={i} onClick={() => { setMode(f.mode); if(topic) handleLearn(topic, f.mode); }} className={`glass p-4 lg:p-5 rounded-[2.2rem] space-y-4 hover:bg-white/80 transition-all cursor-pointer group border-transparent hover:border-white hover:shadow-2xl hover:shadow-blue-500/10 ${mode === f.mode ? 'bg-white/80 ring-2 ring-blue-500/20' : ''}`}>
              <div className={`${f.color} w-10 h-10 rounded-2xl flex items-center justify-center transition-all group-hover:scale-110 group-hover:rotate-6`}>{f.icon}</div>
              <div>
                <h4 className="font-black text-slate-900 text-sm">{f.title}</h4>
                <p className="text-[10px] text-slate-400 font-bold tracking-tight">{f.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderHomeRight = () => (
    <div className="h-full max-w-4xl mx-auto lg:mx-0">
      {state.loading ? (
          <div className="flex flex-col items-center justify-center py-20 px-10 text-center animate-in fade-in slide-in-from-bottom-4 duration-500 bg-white/40 backdrop-blur rounded-[3rem] border border-white h-full shadow-inner">
              <div className="relative mb-8">
                  <div className="w-24 h-24 border-4 border-white/30 border-t-blue-600 rounded-full animate-spin shadow-2xl"></div>
                  <BrainCircuit className="w-10 h-10 text-blue-600 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />
              </div>
              <h3 className="text-2xl font-black text-slate-900 mb-2">Synthesizing Logic</h3>
              <p className="text-slate-500 text-xs font-black uppercase tracking-[0.3em] animate-pulse">Accessing Neural Weights...</p>
          </div>
      ) : state.error ? (
          <div className="glass p-12 rounded-[3rem] text-center border-red-100 animate-in zoom-in-95 duration-300 h-full flex flex-col items-center justify-center shadow-inner">
              <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-6" />
              <h3 className="text-2xl font-black text-slate-900 mb-2">Research Blocked</h3>
              <p className="text-slate-500 text-base font-semibold mb-8 max-w-sm mx-auto leading-relaxed">{state.error}</p>
              <button onClick={clearResearch} className="px-8 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-600 transition-all shadow-xl shadow-slate-900/10">Try Different Logic</button>
          </div>
      ) : state.content ? (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700 pb-20">
              {/* Visual Part */}
              {state.imageUrl && (
                  <div className="glass rounded-[3rem] overflow-hidden shadow-2xl border-white group relative">
                      <img src={state.imageUrl} alt="Diagram" className="w-full object-cover max-h-[500px]" />
                      <div className="absolute top-6 right-6">
                          <a href={state.imageUrl} download="diagram.png" className="p-4 bg-white/90 backdrop-blur-md rounded-2xl text-slate-900 shadow-xl hover:scale-110 active:scale-90 transition-all flex"><Download className="w-5 h-5" /></a>
                      </div>
                  </div>
              )}
              
              {/* Audio Part */}
              {state.audioUrl && (
                  <div className="glass p-8 rounded-[3rem] flex items-center space-x-8 border-white bg-blue-50/50">
                      <div className="w-16 h-16 bg-blue-600 rounded-[1.5rem] flex items-center justify-center text-white shadow-xl animate-pulse"><Headphones className="w-8 h-8" /></div>
                      <div className="flex-1">
                        <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-2">Narration Active</p>
                        <audio controls src={state.audioUrl} className="h-10 w-full" />
                      </div>
                  </div>
              )}

              {/* Textual Content */}
              <div className="glass p-8 md:p-14 rounded-[3.5rem] shadow-2xl border-white bg-white/60">
                  <div className="flex items-center justify-between mb-10">
                      <div className="flex items-center space-x-3">
                        <span className="w-3 h-3 bg-emerald-500 rounded-full animate-ping" />
                        <span className="text-[10px] font-black text-emerald-600 tracking-[0.2em] uppercase">Synthesis Stream Ready</span>
                      </div>
                      <div className="text-[10px] font-black text-slate-400 tracking-widest uppercase">ID: {Math.random().toString(36).substring(7).toUpperCase()}</div>
                  </div>
                  {state.content.split('\n').map((line, idx) => {
                      const trimmed = line.trim();
                      if (!trimmed) return <div key={idx} className="h-6" />;
                      if (trimmed.startsWith('LEARNING OBJECTIVE:')) {
                          return (
                              <div key={idx} className="bg-slate-900 p-10 rounded-[2.5rem] mb-12 shadow-2xl relative overflow-hidden group/goal">
                                  <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/10 rounded-full blur-3xl group-hover/goal:scale-150 transition-transform duration-1000" />
                                  <span className="text-blue-400 font-black text-[10px] uppercase tracking-[0.4em] block mb-3">Goal Vector</span>
                                  <p className="text-white font-extrabold text-xl lg:text-2xl leading-snug">{trimmed.replace('LEARNING OBJECTIVE:', '')}</p>
                              </div>
                          );
                      }
                      if (trimmed.length > 3 && trimmed === trimmed.toUpperCase() && !trimmed.startsWith('-')) {
                          return <h3 key={idx} className="text-2xl font-black text-slate-900 mt-12 mb-6 uppercase tracking-tighter flex items-center group/h"><span className="w-2 h-8 bg-blue-600 rounded-full mr-6 group-hover/h:h-10 transition-all" />{trimmed}</h3>;
                      }
                      return <p key={idx} className="mb-6 text-slate-600 text-lg font-semibold leading-relaxed hover:text-slate-900 transition-colors">{trimmed}</p>;
                  })}
              </div>
          </div>
      ) : (
          <div className="h-full flex flex-col items-center justify-center p-12 text-center bg-white/20 backdrop-blur rounded-[3rem] border border-white/40 border-dashed animate-pulse duration-[4000ms]">
            <History className="w-20 h-20 text-slate-300 mb-8" />
            <h2 className="text-3xl font-black text-slate-400 tracking-tighter mb-4">Awaiting Laboratory Synthesis</h2>
            <p className="text-slate-500 text-base font-medium max-w-md mx-auto">Input your machine learning inquiry on the left panel to begin a real-time expert synthesis session.</p>
          </div>
      )}
    </div>
  );

  const renderHomeContent = () => (
    <div className="h-screen flex flex-col md:flex-row overflow-hidden max-w-[1800px] mx-auto w-full">
        {/* LEFT COLUMN: FIXED WIDTH SIDEBAR */}
        <div className="w-full md:w-[380px] lg:w-[450px] p-6 lg:p-10 md:overflow-y-auto border-r border-white/20 flex-shrink-0 bg-white/5">
          {renderHomeLeft()}
        </div>
        
        {/* RIGHT COLUMN: DYNAMIC RESULTS */}
        <div className="flex-1 p-6 lg:p-14 overflow-y-auto bg-white/10 scroll-smooth">
          {renderHomeRight()}
        </div>
    </div>
  );

  const renderProfile = () => (
    <div className="max-w-md mx-auto px-6 pt-10 pb-32 space-y-8 animate-in fade-in slide-in-from-right-10 duration-700">
      <div className="text-center space-y-4">
        <div className="relative inline-block">
          <div className="w-28 h-28 rounded-[2.5rem] bg-white p-1 shadow-2xl border border-white/50 overflow-hidden mx-auto hover:rotate-3 transition-transform cursor-pointer">
            <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${userName || 'Valmiki'}&backgroundColor=b6e3f4`} alt="Avatar" className="w-full h-full object-cover rounded-[2rem]" />
          </div>
          <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-blue-600 rounded-2xl flex items-center justify-center text-white border-4 border-[#F3E7FF] shadow-lg"><Settings className="w-5 h-5" /></div>
        </div>
        <div className="space-y-1">
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">{userName || 'Researcher'}</h2>
          <p className="text-blue-600 font-black text-[10px] uppercase tracking-widest bg-blue-50 px-3 py-1 rounded-full inline-block">Pro Level Explorer</p>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="glass p-6 rounded-[2.5rem] flex flex-col items-center text-center space-y-2 group hover:bg-blue-600 hover:text-white transition-all">
          <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center group-hover:bg-white/20 group-hover:text-white transition-colors"><Target className="w-5 h-5" /></div>
          <div><p className="text-2xl font-black">24</p><p className="text-[10px] font-black uppercase opacity-60">Modules Done</p></div>
        </div>
        <div className="glass p-6 rounded-[2.5rem] flex flex-col items-center text-center space-y-2 group hover:bg-indigo-600 hover:text-white transition-all">
          <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center group-hover:bg-white/20 group-hover:text-white transition-colors"><Clock className="w-5 h-5" /></div>
          <div><p className="text-2xl font-black">128h</p><p className="text-[10px] font-black uppercase opacity-60">Total Lab Time</p></div>
        </div>
      </div>
      <div className="space-y-4">
        <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.3em] px-2">Account Control</h3>
        <div className="glass rounded-[2.5rem] overflow-hidden border-white divide-y divide-white/20">
          {[{ icon: User, label: "Researcher Details", color: "text-blue-500" }, { icon: Shield, label: "Security Logic", color: "text-indigo-500" }, { icon: CreditCard, label: "Token Billing", color: "text-purple-500" }, { icon: Briefcase, label: "Research Projects", color: "text-pink-500" }].map((item, i) => (
            <button key={i} className="w-full p-6 flex items-center justify-between hover:bg-white/60 transition-all group">
              <div className="flex items-center space-x-4">
                <div className={`w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center ${item.color} group-hover:scale-110 transition-transform`}><item.icon className="w-5 h-5" /></div>
                <span className="font-black text-sm text-slate-700">{item.label}</span>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-300 group-hover:translate-x-1 transition-transform" />
            </button>
          ))}
        </div>
      </div>
      <button onClick={handleLogout} className="w-full py-5 bg-white border border-red-100 text-red-600 rounded-[2.5rem] font-black text-xs uppercase tracking-widest shadow-xl shadow-red-500/5 hover:bg-red-50 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center space-x-3"><LogOut className="w-5 h-5" /><span>Terminate Session</span></button>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'settings': return renderProfile();
      case 'lab': return (
        <div className="flex flex-col items-center justify-center py-40 px-10 text-center animate-in fade-in duration-500">
          <Terminal className="w-16 h-16 text-slate-400 mb-6" />
          <h2 className="text-2xl font-black text-slate-900 mb-2">Researcher Lab</h2>
          <p className="text-slate-500 text-sm font-semibold max-w-xs">Integrated IDEs for neural experiments coming soon.</p>
        </div>
      );
      case 'saved': return (
        <div className="flex flex-col items-center justify-center py-40 px-10 text-center animate-in fade-in duration-500">
          <Layout className="w-16 h-16 text-slate-400 mb-6" />
          <h2 className="text-2xl font-black text-slate-900 mb-2">Knowledge Base</h2>
          <p className="text-slate-500 text-sm font-semibold max-w-xs">Your saved models and research notes will be synchronized here.</p>
        </div>
      );
      default: return renderHomeContent();
    }
  };

  return (
    <div className="min-h-screen text-slate-900 selection:bg-blue-600/20 overflow-hidden flex justify-center items-center">
      <div className="fixed -top-20 -left-20 w-80 h-80 bg-purple-400/20 rounded-full blur-[100px] pointer-events-none animate-pulse"></div>
      <div className="fixed -bottom-20 -right-20 w-80 h-80 bg-blue-400/20 rounded-full blur-[100px] pointer-events-none animate-pulse" style={{ animationDelay: '2s' }}></div>
      <main className="relative z-10 w-full h-full min-h-screen">{!isLoggedIn ? renderLogin() : renderContent()}</main>
      
      {/* PERSISTENT NAVIGATION */}
      {isLoggedIn && (
        <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 w-fit glass px-6 py-4 rounded-[2.5rem] shadow-2xl border border-white/40 flex items-center space-x-10 z-50">
          {[{ id: 'home', icon: Home, label: 'Home' }, { id: 'lab', icon: Terminal, label: 'Lab' }, { id: 'saved', icon: Layout, label: 'Notes' }, { id: 'settings', icon: User, label: 'Me' }].map((tab) => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} className={`flex flex-col items-center space-y-1 transition-all duration-300 relative group ${activeTab === tab.id ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600 hover:translate-y-[-2px]'}`}>
              <div className={`p-2.5 rounded-2xl transition-all duration-300 group-active:scale-90 ${activeTab === tab.id ? 'bg-blue-100/50 shadow-lg shadow-blue-500/10' : 'bg-transparent group-hover:bg-white/40'}`}>
                <tab.icon className={`w-6 h-6 transition-all duration-300 ${activeTab === tab.id ? 'scale-110' : 'scale-100 group-hover:scale-110'}`} />
              </div>
              <span className={`text-[8px] font-black uppercase tracking-widest transition-all duration-300 ${activeTab === tab.id ? 'opacity-100' : 'opacity-60 group-hover:opacity-100'}`}>{tab.label}</span>
              {activeTab === tab.id && <span className="absolute -top-1 w-1 h-1 bg-blue-600 rounded-full"></span>}
            </button>
          ))}
        </nav>
      )}
    </div>
  );
};

export default App;
