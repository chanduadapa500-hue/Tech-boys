
import { GoogleGenAI, Modality } from "@google/genai";
import { LearningMode, Depth } from "../types";

const SYSTEM_INSTRUCTION = `
You are an expert Machine Learning Tutor (Valmiki) providing specialized educational content ONLY for topics related to Artificial Intelligence (AI), Machine Learning (ML), and Deep Learning (DL).

STRICT TOPIC GUARDRAILS:
- You MUST ONLY respond to AI, ML, or DL topics. 
- If a user asks about anything else (e.g., cooking, general programming, history), respond with exactly: "I apologize, but my expertise is strictly limited to the domains of Artificial Intelligence, Machine Learning, and Deep Learning."
- If a file is provided, analyze it strictly through the lens of AI/ML concepts.

PEDAGOGICAL STRUCTURE:
1. LEARNING OBJECTIVE: Every response MUST start with a clear, concise learning objective. Format it as: "LEARNING OBJECTIVE: By the end of this session, you will [specific outcome]."
2. CONTENT: Provide structured, technical explanations. Use ALL CAPS for section headers.
3. DEPTH: 
   - Brief: Concise summary.
   - Detailed: Comprehensive explanation with 5-7 paragraphs.
   - Comprehensive: In-depth mathematical foundations (using LaTeX-style notation where needed) and architectural details.

CODE MODALITY (When Mode is CODE):
- Explain the concept first.
- Provide a clear list of DEPENDENCIES (e.g., pip install numpy pandas).
- Provide ENVIRONMENT INSTRUCTIONS (e.g., "Best run in Google Colab or a local Jupyter environment with GPU support").
- Provide the code in a standard python block.
- Include "EXPECTED OUTPUT" comments at the bottom of the code.

AUDIO/VISUAL MODALITIES:
- AUDIO: Generate a conversational script with (Pause) markers.
- VISUAL: Generate a detailed prompt for a technical diagram architectural flow.
`;

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    // Correctly initializing GoogleGenAI strictly with process.env.API_KEY.
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async generateEducationalContent(topic: string, mode: LearningMode, depth: Depth, fileData?: { data: string, mimeType: string }) {
    const textPart = { text: `Topic: ${topic}\nMode: ${mode}\nRequested Depth: ${depth}\n\nTask: Provide expert ML tutoring content based on the prompt and any attached materials.` };
    
    const contents: any[] = [textPart];
    
    if (fileData) {
      contents.push({
        inlineData: {
          data: fileData.data,
          mimeType: fileData.mimeType
        }
      });
    }

    const response = await this.ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: { parts: contents },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    return response.text || '';
  }

  async generateAudio(text: string) {
    const response = await this.ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `Narrate the following educational content clearly: ${text}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) throw new Error("Audio generation failed");

    return this.decodeAudioBytesToUrl(base64Audio);
  }

  async generateVisual(topic: string) {
    const prompt = `A highly technical, clean, professional educational diagram illustrating the core concepts of: ${topic}. Use a white background, minimal text, and clear architectural flow for Machine Learning concepts. Professional engineering aesthetic.`;
    
    const response = await this.ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: "16:9"
        }
      }
    });

    // Iterate through all parts to find the image part, as recommended by guidelines.
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("Image generation failed");
  }

  // Implementation of base64 decoding following guidelines.
  private decode(base64: string): Uint8Array {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }

  // Audio decoding logic for raw PCM data.
  private async decodeAudioBytesToUrl(base64: string): Promise<string> {
    const bytes = this.decode(base64);
    const sampleRate = 24000;
    const numChannels = 1;

    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate });
    const dataInt16 = new Int16Array(bytes.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = audioContext.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }

    const wavBlob = await this.bufferToWavBlob(buffer);
    return URL.createObjectURL(wavBlob);
  }

  // Converts AudioBuffer to WAV format for browser playback compatibility.
  private async bufferToWavBlob(buffer: AudioBuffer): Promise<Blob> {
    const numOfChan = buffer.numberOfChannels;
    const length = buffer.length * numOfChan * 2 + 44;
    const bufferArray = new ArrayBuffer(length);
    const view = new DataView(bufferArray);
    const channels = [];
    let i, sample, offset = 0, pos = 0;

    const setUint32 = (data: number) => { view.setUint32(pos, data, true); pos += 4; };
    const setUint16 = (data: number) => { view.setUint16(pos, data, true); pos += 2; };

    setUint32(0x46464952); // "RIFF"
    setUint32(length - 8);
    setUint32(0x45564157); // "WAVE"
    setUint32(0x20746d66); // "fmt "
    setUint32(16);
    setUint16(1);
    setUint16(numOfChan);
    setUint32(buffer.sampleRate);
    setUint32(buffer.sampleRate * 2 * numOfChan);
    setUint16(numOfChan * 2);
    setUint16(16);
    setUint32(0x61746164); // "data"
    setUint32(length - pos - 4);

    for (i = 0; i < numOfChan; i++) channels.push(buffer.getChannelData(i));

    while (pos < length) {
      for (i = 0; i < numOfChan; i++) {
        sample = Math.max(-1, Math.min(1, channels[i][offset]));
        sample = (sample < 0 ? sample * 0x8000 : sample * 0x7FFF) | 0;
        view.setInt16(pos, sample, true);
        pos += 2;
      }
      offset++;
    }
    return new Blob([bufferArray], { type: 'audio/wav' });
  }
}
