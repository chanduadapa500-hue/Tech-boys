
export enum LearningMode {
  TEXT = 'TEXT',
  CODE = 'CODE',
  AUDIO = 'AUDIO',
  VISUAL = 'VISUAL'
}

export enum Depth {
  BRIEF = 'BRIEF',
  DETAILED = 'DETAILED',
  COMPREHENSIVE = 'COMPREHENSIVE'
}

export interface GenerationState {
  loading: boolean;
  content: string | null;
  audioUrl: string | null;
  imageUrl: string | null;
  error: string | null;
}

export interface LearningRequest {
  topic: string;
  mode: LearningMode;
  depth: Depth;
}
